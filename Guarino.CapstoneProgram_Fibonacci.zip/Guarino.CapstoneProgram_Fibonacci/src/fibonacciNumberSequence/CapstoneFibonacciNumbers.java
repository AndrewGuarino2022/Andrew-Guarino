package fibonacciNumberSequence;

public class CapstoneFibonacciNumbers
{
	public CapstoneFibonacciNumbers()
	{
		//Design Fibonacci Numbers 
			//0 1 1 2 3 5 8 13 21 34 55 89 144 233 377 etc
		//Display Fibonacci Numbers once calculated 

		//class name is CapstoneFibonacciNumbers the name might change when I go to start programming the numbers
		
		//int will be used to define the fibonacci numbers 
			// int n = 0, int p = 1, int q
		//loop will be created for each calulation of the fibonacci numbers
			//using for loop
		//after each loop is done it will be using a way to print to the console or pop up with what was inputted. 
		
		//Wireframe (layout)
			//first loop will have the loop then be printed or with a pop up message
			//it will then continue to do the rest for the addintional 49 times to finsh the required first 50 fibonacci numbers
			//a trailler can be imputted at anytime to end the program
			//after the fibonacii numbers were all printed a message will appear that no more number will be printed
		
		//UI would have a design of the interface that the user will see
			
	}
}
