package fibonacciNumberSequence;

import javax.swing.JOptionPane;

public class FibonacciProgram
{
	public FibonacciProgram()
	{
		fibonacciCount();
	}

	public void fibonacciCount()
	{
		int n = 0;
		int p = 1;
		int q;
		String outputString = "";

		for (int count = 0; count < 45; count++)
		{
			q = n + p;
			n = p;
			p = q;

			outputString += q + " , " ;
			
			if (count %10 == 0 && count != 0)
			{
				outputString += "\n";
			}

		} 
			JOptionPane.showMessageDialog(null, outputString);

	}

}
