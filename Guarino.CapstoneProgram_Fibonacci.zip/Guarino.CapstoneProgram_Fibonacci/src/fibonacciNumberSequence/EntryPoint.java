package fibonacciNumberSequence;

public class EntryPoint
{

	public static void main(String[] args)
	{
		new FibonacciProgram();
	}

}
